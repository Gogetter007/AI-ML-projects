from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
# Import the email modules we'll need
from email.message import EmailMessage
import zomatopy
import json
import requests
# Import smtplib for the email sending function
import smtplib
from concurrent.futures import ThreadPoolExecutor

email_rest_details = []


class ActionSearchRestaurants(Action):
    def name(self):
        return 'action_search_restaurant'

    def run(self, dispatcher, tracker, domain):
        config = {"user_key": "60b414a69ecb9c8eede3b94d8a3a1424"}
        zomato = zomatopy.initialize_app(config)
        print("inside action search")
        # Get location from slot
        loc = tracker.get_slot('location')

        # Get cuisine from slot
        cuisine = tracker.get_slot('cuisine')
        min_cost = tracker.get_slot('minbudget')
        max_cost = tracker.get_slot('maxbudget')
        print(min_cost,max_cost)
        loc_details, lat, lon = self.get_location_details(loc, zomato)

        if (loc_details == 0):
            # Zomato API could not find suggestions for this location.
            restaurant_exist = False
            dispatcher.utter_message("Sorry, no results found in this location:(" + "\n")
        else:
            rest_details = self.get_restaurants(lat, lon, cuisine)

            # Filter the restaurants based on budget
            budget_rest = [details for details in rest_details if
                        ((int(details['restaurant']['average_cost_for_two']) > int(min_cost)) & (
                                int(details['restaurant']['average_cost_for_two']) < int(max_cost)))]

            # Sort the restaurants according to the restaurant's ratings
            budget_rest_sort = sorted(budget_rest,
                                            key=lambda k: k['restaurant']['user_rating']['aggregate_rating'],
                                            reverse=True)
            # Build the bot response
            bot_response = ""
            restaurant_exist = False
            if len(budget_rest_sort) == 0:
                dispatcher.utter_message("Sorry, no results found :(" + "\n")
            else:
                # Pick the top 5
                budget_rating_top5_rest = budget_rest_sort[:5]
                global email_rest_details

                # store the top 10 restaurants incase user ask the bot to send a mail of the list
                email_rest_details = budget_rest_sort[:10]
                if (len(email_rest_details) > 0):
                    restaurant_exist = True
                for restaurant in budget_rating_top5_rest:
                    bot_response = bot_response + restaurant['restaurant']['name'] + " in " + \
                               restaurant['restaurant']['location']['address'] + \
                               " has been rated " + \
                               restaurant['restaurant']['user_rating']['aggregate_rating'] + "\n" + "\n"
                dispatcher.utter_message("Here are our picks!" + "\n" + bot_response)
        return [SlotSet('location', loc), SlotSet('restaurant_exist', restaurant_exist)]

    def get_location_details(self, loc, zomato):
        # Get location details including latitude and longitude
        location_detail = zomato.get_location(loc, 1)
        d1 = json.loads(location_detail)
        lat = 0
        lon = 0
        loc_info = len(d1["location_suggestions"])
        if (loc_info > 0):
            lat = d1["location_suggestions"][0]["latitude"]
            lon = d1["location_suggestions"][0]["longitude"]
        return loc_info, lat, lon

    def get_restaurants(self, lat, lon, cuisine):
        cuisines_dict = {'american': 1, 'chinese': 25, 'italian': 55,
                         'mexican': 73, 'north indian': 50, 'south indian': 85}
        rest_details = []
        executor = ThreadPoolExecutor(max_workers=5)
        for res_key in range(0, 101, 20):
            executor.submit(retrieve_restaurant, lat, lon, cuisines_dict, cuisine, res_key, rest_details)
        executor.shutdown()
        return rest_details

class ValidateLocation(Action):
    TIER_1 = []
    TIER_2 = []

    def __init__(self):
        self.TIER_1 = ['ahmedabad', 'bangalore', 'chennai',
                       'delhi', 'hyderabad', 'kolkata', 'mumbai', 'pune']
        self.TIER_2 = ['agra', 'ajmer', 'aligarh', 'allahabad', 'amravati', 'amritsar', 'asansol', 'aurangabad',
                       'bareilly', 'belgaum', 'bhavnagar', 'bhiwandi', 'bhopal', 'bhubaneswar', 'bikaner',
                       'bokaro steel city', 'chandigarh', 'coimbatore', 'cuttack', 'dehradun', 'dhanbad',
                       'durg-bhilai nagar', 'durgapur', 'erode', 'faridabad', 'firozabad', 'ghaziabad', 'gorakhpur',
                       'gulbarga', 'guntur', 'gurgaon', 'guwahati', 'gwalior', 'hubli-dharwad', 'indore', 'jabalpur',
                       'jaipur', 'jalandhar', 'jammu', 'jamnagar', 'jamshedpur', 'jhansi', 'jodhpur', 'kannur',
                       'kanpur', 'kakinada', 'kochi',
                       'kottayam', 'kolhapur', 'kollam', 'kota', 'kozhikode', 'kurnool', 'lucknow', 'ludhiana',
                       'madurai', 'malappuram', 'mathura', 'goa', 'mangalore', 'meerut', 'moradabad', 'mysore',
                       'nagpur', 'nanded', 'nashik', 'nellore', 'noida', 'palakkad', 'patna', 'pondicherry', 'raipur',
                       'rajkot', 'rajahmundry', 'ranchi', 'rourkela', 'salem', 'sangli', 'siliguri', 'solapur',
                       'srinagar', 'sultanpur', 'surat', 'thiruvananthapuram', 'thrissur', 'tiruchirappalli',
                       'tirunelveli', 'tiruppur', 'ujjain', 'vijayapura', 'vadodara', 'varanasi', 'vasai-virar city',
                       'vijayawada', 'visakhapatnam', 'warangal']

    def name(self):
        return "validate_location"

    def run(self, dispatcher, tracker, domain):
        loc = tracker.get_slot('location')
        if not (self.validate_location(loc)):
            dispatcher.utter_message(
                "We do not operate in " + loc + " yet. Please try some other city.")
            return [SlotSet('location', None), SlotSet("location_valid", False)]
        else:
            return [SlotSet('location', loc), SlotSet("location_valid", True)]

    def validate_location(self, loc):
        return loc.lower() in self.TIER_1 or loc.lower() in self.TIER_2


class ActionSendEmail(Action):
    def name(self):
        return 'action_send_email'

    def run(self, dispatcher, tracker, domain):
        # Get user's email id
        to_email = tracker.get_slot('emailid')

        # Get location and cuisines to put in the email
        loc = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        global email_rest_details
        email_rest_count = len(email_rest_details)
        # Construct the email 'subject' and the contents.
        email_subj = "Top " + str(email_rest_count) + " " + cuisine.capitalize() + " restaurants in " + str(
            loc).capitalize()
        email_msg = "Hi there! Here are the " + email_subj + "." + "\n" + "\n" + "\n"
        for restaurant in email_rest_details:
            email_msg = email_msg + restaurant['restaurant']['name'] + " in " + \
                          restaurant['restaurant']['location']['address'] + " has been rated " + \
                          restaurant['restaurant']['user_rating']['aggregate_rating'] + "\n" + "\n"

        # Open SMTP connection to our email id.
        s = smtplib.SMTP("smtp.gmail.com", 587)
        s.starttls()
        s.login("zomafood95@gmail.com", "zomato123")

        # Create the msg object
        msg = EmailMessage()

        # Fill in the message properties
        msg['Subject'] = email_subj
        msg['From'] = "zomafood95@gmail.com"

        # Fill in the message content
        msg.set_content(email_msg)
        msg['To'] = to_email

        s.send_message(msg)
        s.quit()
        dispatcher.utter_message("Details sent.. Have a happy meal..!!! :) :) :)")
        return []

class ValidateBudget(Action):

    def name(self):
        return "validate_budget"

    def run(self, dispatcher, tracker, domain):
        minbudget = None
        maxbudget = None
        error_msg = "Sorry!! price range not supported, please re-enter."
        try:
            minbudget = int(tracker.get_slot('minbudget'))
            maxbudget = int(tracker.get_slot('maxbudget'))
        except ValueError:
            dispatcher.utter_message(error_msg)
            return [SlotSet('minbudget', None), SlotSet('maxbudget', None), SlotSet('budget_valid', False)]
        min_dict = [0, 300, 700]
        max_dict = [300, 700]
        if minbudget in min_dict and (maxbudget in max_dict or maxbudget > 700):
            return [SlotSet('minbudget', minbudget), SlotSet('maxbudget', maxbudget), SlotSet('budget_valid', True)]
        else:
            dispatcher.utter_message(error_msg)
            return [SlotSet('minbudget', 0), SlotSet('maxbudget', 10000), SlotSet('budget_valid', False)]

class ValidateCuisine(Action):

    def name(self):
        return "validate_cuisine"

    def run(self, dispatcher, tracker, domain):
        cuisines = ['chinese', 'mexican', 'italian', 'american', 'south indian', 'north indian']
        error_msg = "Sorry!! The cuisine is not supported. Please re-enter."
        cuisine = tracker.get_slot('cuisine')
        try:
            cuisine = cuisine.lower()
        except (RuntimeError, TypeError, NameError, AttributeError):
            dispatcher.utter_message(error_msg)
            return [SlotSet('cuisine', None), SlotSet('cuisine_valid', False)]
        if cuisine in cuisines:
            return [SlotSet('cuisine', cuisine), SlotSet('cuisine_valid', True)]
        else:
            dispatcher.utter_message(error_msg)
            return [SlotSet('cuisine', None), SlotSet('cuisine_valid', False)]


def retrieve_restaurant(lat, lon, cuisines_dict, cuisine, res_key, rest_details):
    base_url = "https://developers.zomato.com/api/v2.1/"
    headers = {'Accept': 'application/json',
               'user-key': '60b414a69ecb9c8eede3b94d8a3a1424'}
    try:
        results = (requests.get(base_url + "search?" + "&lat=" + str(lat) + "&lon=" + str(lon) + "&cuisines=" + str(
            cuisines_dict.get(cuisine)) + "&start=" + str(res_key) + "&count=20", headers=headers).content).decode(
            "utf-8")
    except:
        return
    details = json.loads(results)
    rest_details.extend(details['restaurants'])
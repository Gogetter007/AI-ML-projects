This file provides the complete packages needed for the chatbot.


Team Members:
1. Kanchari Srikanth  - kanchari.srikanth@yahoo.com
2. Arjun Murthy - murthyarjun02@gmail.com

The follwoing are the versions used:

1. Python 3.7.7
2. pip-20.0.2
3. Rasa 1.9.6

Installation Steps :

1. Install Python 3.7.7
2. Install and upgrade pip-20.0.2
3. Install Rasa

To test:
1. open command prompt and move to the unzipped chatbot directory
2. type command "rasa train"
3. type command "rasa run actions"
4. open another command prompt and move to the chatbot directory
5. type command "rasa shell"
6. input your queries


Sample Example : please refer to screenshot : "output/SampleTestRun.jpeg" in the directory.





